export class TokenJWT{
    password!: string;
    surname!: string;
    name!: string;
    email!:string;
    expDate!:Date;
    username!:string;
    role!:string;
}